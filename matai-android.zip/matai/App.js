import React, { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { getKey } from './src/lib/store';
import { C } from './src/ui';
import Studio from './src/screens/Studio';
import LipSync from './src/screens/LipSync';
import Library from './src/screens/Library';
import Settings from './src/screens/Settings';

const TABS = [
  { id: 'image', label: 'Image' },
  { id: 'video', label: 'Video' },
  { id: 'lipsync', label: 'Lip Sync' },
  { id: 'library', label: 'Library' },
  { id: 'settings', label: 'Setting' },
];

function Shell() {
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState('image');
  useEffect(() => { getKey().then((k) => { if (!k) setTab('settings'); }); }, []);

  const show = (id) => ({ flex: 1, display: tab === id ? 'flex' : 'none' });
  return (
    <View style={{ flex: 1, backgroundColor: C.bg, paddingTop: insets.top }}>
      <StatusBar style="light" />
      <View style={show('image')}><Studio mode="image" /></View>
      <View style={show('video')}><Studio mode="video" /></View>
      <View style={show('lipsync')}><LipSync /></View>
      <View style={show('library')}><Library active={tab === 'library'} /></View>
      <View style={show('settings')}><Settings onSaved={() => setTab('image')} /></View>
      <View style={{ flexDirection: 'row', backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.line, paddingBottom: insets.bottom }}>
        {TABS.map((t) => (
          <Pressable key={t.id} onPress={() => setTab(t.id)} style={{ flex: 1, paddingVertical: 14, alignItems: 'center' }}>
            <Text style={{ color: tab === t.id ? C.acc : C.mute, fontWeight: '700', fontSize: 12 }}>{t.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export default function App() {
  return <SafeAreaProvider><Shell /></SafeAreaProvider>;
}
