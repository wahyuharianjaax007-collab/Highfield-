# MATAI Android (native, tanpa WebView)

Aplikasi React Native (Expo) yang memanggil API kie.ai langsung dari perangkat.
Tidak ada backend Netlify, tidak ada login nama/PIN. Cukup API key kie.ai di tab Setting.

## Build APK lewat GitHub
1. Buat repo baru (misal `matai-android`) dan upload semua isi folder ini.
2. Tab Actions -> "Build Android APK" -> Run workflow (tunggu sekitar 10-20 menit).
3. Unduh artifact `MATAI-apk`, ekstrak, pasang `app-release.apk`.
