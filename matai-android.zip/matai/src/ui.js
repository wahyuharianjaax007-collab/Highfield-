import React from 'react';
import { View, Text, Pressable, ScrollView, Image, StyleSheet } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { isVideoUrl } from './lib/kie';

export const C = { bg: '#0b0b0f', card: '#16161d', line: '#2a2a35', text: '#f2f2f5', mute: '#8b8b99', acc: '#c6ff3d', danger: '#ff5d5d' };

export const s = StyleSheet.create({
  page: { padding: 16, paddingBottom: 40, gap: 14 },
  label: { color: C.mute, fontSize: 12, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6 },
  input: { backgroundColor: C.card, color: C.text, borderRadius: 12, borderWidth: 1, borderColor: C.line, padding: 12, fontSize: 15 },
  hint: { color: C.mute, fontSize: 12 },
  title: { color: C.text, fontSize: 22, fontWeight: '800' },
});

export function Chips({ label, options, value, onChange }) {
  if (!options || !options.length) return null;
  const opts = options.map((o) => (typeof o === 'object' ? o : { value: o, label: String(o) }));
  return (
    <View>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {opts.map((o) => {
          const on = o.value === value;
          return (
            <Pressable key={String(o.value)} onPress={() => onChange(o.value)}
              style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1,
                borderColor: on ? C.acc : C.line, backgroundColor: on ? C.acc : C.card }}>
              <Text style={{ color: on ? '#000' : C.text, fontWeight: '600', fontSize: 13 }}>{o.label}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

export function Btn({ title, onPress, disabled, kind }) {
  const bg = kind === 'ghost' ? C.card : kind === 'danger' ? C.danger : C.acc;
  const fg = kind === 'ghost' ? C.text : '#000';
  return (
    <Pressable onPress={onPress} disabled={disabled}
      style={{ backgroundColor: bg, opacity: disabled ? 0.5 : 1, borderRadius: 12, paddingVertical: 13, alignItems: 'center',
        borderWidth: kind === 'ghost' ? 1 : 0, borderColor: C.line }}>
      <Text style={{ color: fg, fontWeight: '800', fontSize: 15 }}>{title}</Text>
    </Pressable>
  );
}

function VideoBox({ url }) {
  const player = useVideoPlayer(url, (p) => { p.loop = true; });
  return <VideoView player={player} style={{ width: '100%', height: 300, borderRadius: 12, backgroundColor: '#000' }} nativeControls contentFit="contain" />;
}

export function Media({ url }) {
  if (!url) return null;
  return isVideoUrl(url)
    ? <VideoBox url={url} />
    : <Image source={{ uri: url }} style={{ width: '100%', height: 340, borderRadius: 12, backgroundColor: '#000' }} resizeMode="contain" />;
}
