import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { CATALOG } from './lib/catalog';
import { loadCached, fetchRemote } from './lib/remote';

const Ctx = createContext({ catalog: CATALOG, ts: null, status: '', refresh: async () => {} });
export const useCatalog = () => useContext(Ctx);

export function CatalogProvider({ children }) {
  const [state, setState] = useState({ catalog: CATALOG, ts: null, status: 'Memakai daftar bawaan' });

  const refresh = useCallback(async () => {
    setState((s) => ({ ...s, status: 'Memperbarui daftar model…' }));
    try {
      const r = await fetchRemote();
      setState({ catalog: r.catalog, ts: r.ts, status: `Daftar online dimuat (${r.catalog.length} model)` });
      return true;
    } catch (e) {
      setState((s) => ({ ...s, status: `Gagal memperbarui: ${e.message}. Memakai daftar tersimpan.` }));
      return false;
    }
  }, []);

  useEffect(() => {
    (async () => {
      const c = await loadCached();
      if (c) setState({ catalog: c.catalog, ts: c.ts, status: `Daftar tersimpan (${c.catalog.length} model)` });
      refresh();
    })();
  }, [refresh]);

  return <Ctx.Provider value={{ ...state, refresh }}>{children}</Ctx.Provider>;
}
