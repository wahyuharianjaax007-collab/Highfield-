import React, { useEffect, useState } from 'react';
import { FlatList, View, Text, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as MediaLibrary from 'expo-media-library';
import { getHistory, removeHistory } from '../lib/store';
import { isVideoUrl } from '../lib/kie';
import { Btn, Media, s, C } from '../ui';

export default function Library({ active }) {
  const [items, setItems] = useState([]);
  useEffect(() => { if (active) getHistory().then(setItems); }, [active]);

  async function save(item) {
    try {
      const perm = await MediaLibrary.requestPermissionsAsync(true);
      if (!perm.granted) throw new Error('Izin galeri ditolak.');
      const ext = isVideoUrl(item.url) ? 'mp4' : 'jpg';
      const dest = `${FileSystem.cacheDirectory}matai-${item.id}.${ext}`;
      const dl = await FileSystem.downloadAsync(item.url, dest);
      await MediaLibrary.saveToLibraryAsync(dl.uri);
      Alert.alert('Tersimpan', 'Sudah masuk ke galeri.');
    } catch (e) { Alert.alert('Gagal', String(e.message || e)); }
  }

  return (
    <FlatList
      data={items}
      keyExtractor={(i) => i.id}
      contentContainerStyle={s.page}
      ListHeaderComponent={<Text style={s.title}>Library</Text>}
      ListEmptyComponent={<Text style={s.hint}>Belum ada hasil. Generate dulu di tab lain.</Text>}
      renderItem={({ item }) => (
        <View style={{ backgroundColor: C.card, borderRadius: 14, padding: 10, gap: 8 }}>
          <Media url={item.url} />
          <Text style={{ color: C.mute, fontSize: 12 }}>{item.model}</Text>
          <Text style={{ color: C.text }} numberOfLines={3}>{item.prompt}</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={{ flex: 1 }}><Btn title="Simpan ke galeri" onPress={() => save(item)} /></View>
            <View style={{ flex: 1 }}><Btn kind="ghost" title="Hapus" onPress={async () => setItems(await removeHistory(item.id))} /></View>
          </View>
        </View>
      )}
    />
  );
}
