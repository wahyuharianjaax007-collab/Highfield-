import React, { useState, useMemo, useEffect } from 'react';
import { ScrollView, View, Text, TextInput, Image, ActivityIndicator, Alert, Pressable } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { t2iModels, i2iModels, t2vModels } from '../lib/models';
import { runModel, uploadFile } from '../lib/kie';
import { getKey, addHistory } from '../lib/store';
import { Chips, Btn, Media, s, C } from '../ui';

export default function Studio({ mode }) {
  const models = useMemo(() => (mode === 'image' ? [...t2iModels, ...i2iModels] : t2vModels), [mode]);
  const [modelId, setModelId] = useState(models[0].id);
  const m = models.find((x) => x.id === modelId) || models[0];
  const [prompt, setPrompt] = useState('');
  const [aspect, setAspect] = useState(null);
  const [res, setRes] = useState(null);
  const [dur, setDur] = useState(5);
  const [imgs, setImgs] = useState([]);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [result, setResult] = useState(null);

  useEffect(() => {
    setAspect(m.aspects?.[0] ?? null);
    setRes(m.resolutionDefault ?? m.resolutions?.[0] ?? null);
    setImgs([]);
  }, [modelId]);

  const maxImgs = m.images?.max || 0;

  async function pick() {
    const r = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'], allowsMultipleSelection: maxImgs > 1, selectionLimit: maxImgs || 1, quality: 0.9,
    });
    if (!r.canceled) setImgs(r.assets.slice(0, maxImgs || 1));
  }

  async function go() {
    try {
      const key = await getKey();
      if (!key) throw new Error('Isi API key kie.ai di tab Setting dulu.');
      if (!prompt.trim()) throw new Error('Prompt masih kosong.');
      if (m.images?.required && !imgs.length) throw new Error('Model ini butuh gambar referensi.');
      setBusy(true); setResult(null);

      const urls = [];
      for (let i = 0; i < imgs.length; i++) {
        setStatus(`Upload gambar ${i + 1}/${imgs.length}…`);
        urls.push(await uploadFile(key, imgs[i]));
      }

      const input = { prompt: prompt.trim() };
      if (aspect) input.aspect_ratio = aspect;
      if (res) input[m.resolutionField || 'resolution'] = res;
      if (m.hasDuration) input.duration = String(dur);
      if (urls.length && m.images) {
        input[m.images.param] = urls;
      }

      setStatus('Mengirim ke kie.ai…');
      const out = await runModel(key, m.id, input, setStatus);
      setResult(out.url);
      await addHistory({ url: out.url, prompt: prompt.trim(), model: m.label || m.id });
    } catch (e) {
      Alert.alert('Gagal', String(e.message || e));
    } finally {
      setBusy(false); setStatus('');
    }
  }

  return (
    <ScrollView contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>{mode === 'image' ? 'Image Studio' : 'Video Studio'}</Text>
      <Chips label="Model" options={models.map((x) => ({ value: x.id, label: x.label || x.id }))} value={modelId} onChange={setModelId} />
      {m.blurb ? <Text style={s.hint}>{m.blurb}</Text> : null}

      <View>
        <Text style={s.label}>Prompt</Text>
        <TextInput style={[s.input, { minHeight: 110, textAlignVertical: 'top' }]} multiline value={prompt} onChangeText={setPrompt}
          placeholder="Deskripsikan yang mau dibuat…" placeholderTextColor={C.mute} />
      </View>

      {maxImgs > 0 && (
        <View>
          <Text style={s.label}>Gambar referensi {m.images.required ? '(wajib)' : '(opsional)'} · maks {maxImgs}</Text>
          <ScrollView horizontal contentContainerStyle={{ gap: 8 }}>
            {imgs.map((a, i) => <Image key={i} source={{ uri: a.uri }} style={{ width: 72, height: 72, borderRadius: 10 }} />)}
            <Pressable onPress={pick} style={{ width: 72, height: 72, borderRadius: 10, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: C.acc, fontSize: 28 }}>+</Text>
            </Pressable>
          </ScrollView>
        </View>
      )}

      <Chips label="Aspect ratio" options={m.aspects} value={aspect} onChange={setAspect} />
      <Chips label="Resolusi" options={m.resolutions} value={res} onChange={setRes} />
      {m.hasDuration && <Chips label="Durasi (detik)" options={[5, 8, 10]} value={dur} onChange={setDur} />}

      <Btn title={busy ? 'Memproses…' : 'Generate'} onPress={go} disabled={busy} />
      {busy && (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <ActivityIndicator color={C.acc} /><Text style={s.hint}>{status}</Text>
        </View>
      )}
      {result && <Media url={result} />}
    </ScrollView>
  );
}
