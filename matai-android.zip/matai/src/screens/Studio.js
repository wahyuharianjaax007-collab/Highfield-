import React, { useState, useMemo, useEffect } from 'react';
import { ScrollView, View, Text, TextInput, Image, ActivityIndicator, Alert, Pressable } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { useCatalog } from '../CatalogContext';
import { runModel, uploadFile } from '../lib/kie';
import { getKey, addHistory } from '../lib/store';
import ModelPicker from '../ModelPicker';
import { Chips, Btn, Media, s, C } from '../ui';

const KINDS = {
  image: { title: 'Image Studio', subs: [{ id: 't2i', label: 'Text → Image' }, { id: 'i2i', label: 'Image → Image' }] },
  video: { title: 'Video Studio', subs: [{ id: 't2v', label: 'Text → Video' }, { id: 'i2v', label: 'Image → Video' }] },
  lipsync: { title: 'Lip Sync', subs: [{ id: 'lip', label: 'Lip Sync' }] },
};

export default function Studio({ kind }) {
  const cfg = KINDS[kind];
  const { catalog } = useCatalog();
  const [sub, setSub] = useState(cfg.subs[0].id);
  const list = useMemo(() => catalog.filter((m) => m.sub === sub), [catalog, sub]);
  const [model, setModel] = useState(list[0]);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [vals, setVals] = useState({});
  const [files, setFiles] = useState([]);
  const [audio, setAudio] = useState(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [result, setResult] = useState(null);

  useEffect(() => { setModel(list[0]); }, [sub]);
  useEffect(() => { if (!list.some((m) => m.key === model.key)) setModel(list[0]); }, [list]);
  useEffect(() => {
    const v = {};
    (model.fields || []).forEach((f) => { if (f.default !== undefined && f.default !== null) v[f.name] = f.default; });
    setVals(v); setFiles([]); setAudio(null);
  }, [model]);

  const media = model.media;

  async function pickMedia() {
    const r = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: [media.kind === 'video' ? 'videos' : 'images'],
      allowsMultipleSelection: media.multi && media.max > 1,
      selectionLimit: media.multi ? media.max : 1,
      quality: 0.9,
    });
    if (!r.canceled) setFiles(r.assets.slice(0, media.max));
  }
  async function pickAudio() {
    const r = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if (!r.canceled) setAudio(r.assets[0]);
  }

  async function go() {
    try {
      const key = await getKey(model.provider);
      if (!key) throw new Error(`Isi API key ${model.provider === 'kie' ? 'kie.ai' : 'muapi.ai'} di tab Setting dulu.`);
      if (model.hasPrompt && model.promptRequired && !prompt.trim()) throw new Error('Prompt masih kosong.');
      if (media?.required && !files.length) throw new Error('Pilih gambar/video input dulu.');
      if (model.audio && !audio) throw new Error('Pilih file audio dulu.');
      setBusy(true); setResult(null);

      const urls = [];
      for (let i = 0; i < files.length; i++) {
        setStatus(`Upload ${i + 1}/${files.length}…`);
        urls.push(await uploadFile(model.provider, key, files[i]));
      }
      let audioUrl = null;
      if (audio) { setStatus('Upload audio…'); audioUrl = await uploadFile(model.provider, key, audio); }

      const input = {};
      if (model.hasPrompt && prompt.trim()) input.prompt = prompt.trim();
      for (const f of model.fields || []) {
        const v = vals[f.name];
        if (v === undefined || v === null || v === '') continue;
        input[f.name] = f.type === 'number' ? Number(v) : f.asString ? String(v) : v;
      }
      if (media && urls.length) input[media.param] = media.multi ? urls : urls[0];
      if (model.audio && audioUrl) input[model.audio] = audioUrl;

      setStatus('Mengirim…');
      const url = await runModel(model, key, input, setStatus);
      setResult(url);
      await addHistory({ url, prompt: prompt.trim() || '(tanpa prompt)', model: model.name });
    } catch (e) {
      Alert.alert('Gagal', String(e.message || e));
    } finally { setBusy(false); setStatus(''); }
  }

  return (
    <ScrollView contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>{cfg.title}</Text>
      {cfg.subs.length > 1 && <Chips options={cfg.subs.map((x) => ({ value: x.id, label: x.label }))} value={sub} onChange={setSub} />}

      <View>
        <Text style={s.label}>Model · {list.length} tersedia</Text>
        <Pressable onPress={() => setPickerOpen(true)}
          style={{ backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.line, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.text, fontWeight: '800', fontSize: 15 }}>{model.name}</Text>
            <Text style={{ color: C.mute, fontSize: 12, marginTop: 2 }}>{model.brand} · {model.provider === 'kie' ? 'kie.ai' : 'muapi.ai'}</Text>
          </View>
          <Text style={{ color: C.acc, fontSize: 18 }}>▾</Text>
        </Pressable>
        {model.blurb ? <Text style={[s.hint, { marginTop: 6 }]}>{model.blurb}</Text> : null}
      </View>

      {model.hasPrompt && (
        <View>
          <Text style={s.label}>Prompt {model.promptRequired ? '' : '(opsional)'}</Text>
          <TextInput style={[s.input, { minHeight: 100, textAlignVertical: 'top' }]} multiline value={prompt} onChangeText={setPrompt}
            placeholder="Deskripsikan yang mau dibuat…" placeholderTextColor={C.mute} />
        </View>
      )}

      {media && (
        <View>
          <Text style={s.label}>{media.kind === 'video' ? 'Video' : 'Gambar'} input {media.required ? '(wajib)' : '(opsional)'}{media.multi ? ` · maks ${media.max}` : ''}</Text>
          <ScrollView horizontal contentContainerStyle={{ gap: 8 }}>
            {files.map((a, i) => <Image key={i} source={{ uri: a.uri }} style={{ width: 72, height: 72, borderRadius: 10, backgroundColor: C.card }} />)}
            <Pressable onPress={pickMedia} style={{ width: 72, height: 72, borderRadius: 10, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: C.acc, fontSize: 28 }}>+</Text>
            </Pressable>
          </ScrollView>
        </View>
      )}

      {model.audio && <Btn kind="ghost" title={audio ? `Audio: ${audio.name}` : 'Pilih file audio'} onPress={pickAudio} />}

      {(model.fields || []).map((f) => {
        const set = (v) => setVals((p) => ({ ...p, [f.name]: v }));
        if (f.type === 'enum') return <Chips key={f.name} label={f.label} options={f.options} value={vals[f.name]} onChange={set} />;
        if (f.type === 'bool') return <Chips key={f.name} label={f.label} options={[{ value: true, label: 'Ya' }, { value: false, label: 'Tidak' }]} value={vals[f.name]} onChange={set} />;
        return (
          <View key={f.name}>
            <Text style={s.label}>{f.label}{f.type === 'number' && (f.min !== undefined || f.max !== undefined) ? ` (${f.min ?? ''}–${f.max ?? ''})` : ''}</Text>
            <TextInput style={s.input} value={vals[f.name] === undefined ? '' : String(vals[f.name])} onChangeText={set}
              keyboardType={f.type === 'number' ? 'numeric' : 'default'} placeholderTextColor={C.mute} />
          </View>
        );
      })}

      <Btn title={busy ? 'Memproses…' : 'Generate'} onPress={go} disabled={busy} />
      {busy && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><ActivityIndicator color={C.acc} /><Text style={s.hint}>{status}</Text></View>}
      {result && <Media url={result} />}

      <ModelPicker visible={pickerOpen} models={list} selected={model} onSelect={setModel} onClose={() => setPickerOpen(false)} />
    </ScrollView>
  );
}
