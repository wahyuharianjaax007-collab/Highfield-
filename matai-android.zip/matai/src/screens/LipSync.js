import React, { useState, useEffect } from 'react';
import { ScrollView, View, Text, TextInput, Image, ActivityIndicator, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { lipsyncModels } from '../lib/models';
import { runModel, uploadFile } from '../lib/kie';
import { getKey, addHistory } from '../lib/store';
import { Chips, Btn, Media, s, C } from '../ui';

export default function LipSync() {
  const [modelId, setModelId] = useState(lipsyncModels[0].id);
  const m = lipsyncModels.find((x) => x.id === modelId) || lipsyncModels[0];
  const [img, setImg] = useState(null);
  const [audio, setAudio] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [vals, setVals] = useState({});
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [result, setResult] = useState(null);

  const resName = m.resolutionField || 'resolution';
  const hasResField = (m.fields || []).some((f) => f.name === resName);

  useEffect(() => {
    const v = {};
    (m.fields || []).forEach((f) => { if (f.default !== undefined) v[f.name] = f.default; });
    if (m.resolutions?.length && !hasResField) v[resName] = m.resolutionDefault ?? m.resolutions[0];
    setVals(v);
  }, [modelId]);

  async function pickImg() {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.9 });
    if (!r.canceled) setImg(r.assets[0]);
  }
  async function pickAudio() {
    const r = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if (!r.canceled) setAudio(r.assets[0]);
  }

  async function go() {
    try {
      const key = await getKey();
      if (!key) throw new Error('Isi API key kie.ai di tab Setting dulu.');
      if (!img || !audio) throw new Error('Pilih gambar potret dan file audio.');
      if (m.promptRequired && !prompt.trim()) throw new Error('Model ini butuh prompt.');
      setBusy(true); setResult(null);
      setStatus('Upload gambar…'); const iu = await uploadFile(key, img);
      setStatus('Upload audio…'); const au = await uploadFile(key, audio);
      const input = { [m.portrait]: iu, [m.audio]: au, ...vals };
      if (prompt.trim()) input.prompt = prompt.trim();
      const out = await runModel(key, m.id, input, setStatus);
      setResult(out.url);
      await addHistory({ url: out.url, prompt: prompt.trim() || '(lip sync)', model: m.label || m.id });
    } catch (e) {
      Alert.alert('Gagal', String(e.message || e));
    } finally { setBusy(false); setStatus(''); }
  }

  return (
    <ScrollView contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Lip Sync</Text>
      <Chips label="Model" options={lipsyncModels.map((x) => ({ value: x.id, label: x.label || x.id }))} value={modelId} onChange={setModelId} />
      {m.blurb ? <Text style={s.hint}>{m.blurb}</Text> : null}

      <Btn kind="ghost" title={img ? 'Ganti gambar potret' : 'Pilih gambar potret'} onPress={pickImg} />
      {img && <Image source={{ uri: img.uri }} style={{ width: 120, height: 120, borderRadius: 12 }} />}
      <Btn kind="ghost" title={audio ? `Audio: ${audio.name}` : 'Pilih file audio'} onPress={pickAudio} />
      {m.audioMaxSeconds ? <Text style={s.hint}>Audio maks {m.audioMaxSeconds} detik.</Text> : null}

      <View>
        <Text style={s.label}>Prompt {m.promptRequired ? '(wajib)' : '(opsional)'}</Text>
        <TextInput style={[s.input, { minHeight: 70, textAlignVertical: 'top' }]} multiline value={prompt} onChangeText={setPrompt}
          placeholder="Contoh: berbicara tenang ke kamera" placeholderTextColor={C.mute} />
      </View>

      {(m.fields || []).map((f) => (
        <Chips key={f.name} label={f.label || f.name} options={f.options} value={vals[f.name]} onChange={(v) => setVals({ ...vals, [f.name]: v })} />
      ))}
      {m.resolutions?.length && !hasResField ? (
        <Chips label="Resolusi" options={m.resolutions} value={vals[resName]} onChange={(v) => setVals({ ...vals, [resName]: v })} />
      ) : null}

      <Btn title={busy ? 'Memproses…' : 'Generate'} onPress={go} disabled={busy} />
      {busy && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><ActivityIndicator color={C.acc} /><Text style={s.hint}>{status}</Text></View>}
      {result && <Media url={result} />}
    </ScrollView>
  );
}
