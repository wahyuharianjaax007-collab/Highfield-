import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, TextInput, Alert } from 'react-native';
import { getKey, setKey } from '../lib/store';
import { Btn, s, C } from '../ui';

export default function Settings({ onSaved }) {
  const [k, setK] = useState('');
  useEffect(() => { getKey().then(setK); }, []);
  return (
    <ScrollView contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Setting</Text>
      <View>
        <Text style={s.label}>API key kie.ai</Text>
        <TextInput style={s.input} value={k} onChangeText={setK} secureTextEntry autoCapitalize="none" autoCorrect={false}
          placeholder="Tempel API key di sini" placeholderTextColor={C.mute} />
        <Text style={[s.hint, { marginTop: 6 }]}>Disimpan hanya di perangkat ini. Ambil key di kie.ai → API Key.</Text>
      </View>
      <Btn title="Simpan" onPress={async () => { await setKey(k); Alert.alert('Tersimpan', 'API key disimpan.'); onSaved && onSaved(); }} />
    </ScrollView>
  );
}
