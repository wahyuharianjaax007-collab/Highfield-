import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, TextInput, Alert } from 'react-native';
import { getKey, setKey } from '../lib/store';
import { Btn, s, C } from '../ui';
import { useCatalog } from '../CatalogContext';
import { getUrl, setUrl, DEFAULT_URL } from '../lib/remote';

export default function Settings({ onSaved }) {
  const [kie, setKie] = useState('');
  const [mu, setMu] = useState('');
  const [url, setUrlState] = useState(DEFAULT_URL);
  const { catalog, ts, status, refresh } = useCatalog();
  useEffect(() => { getKey('kie').then(setKie); getKey('muapi').then(setMu); getUrl().then(setUrlState); }, []);
  const field = (label, v, set, hint) => (
    <View>
      <Text style={s.label}>{label}</Text>
      <TextInput style={s.input} value={v} onChangeText={set} secureTextEntry autoCapitalize="none" autoCorrect={false}
        placeholder="Tempel API key di sini" placeholderTextColor={C.mute} />
      <Text style={[s.hint, { marginTop: 6 }]}>{hint}</Text>
    </View>
  );
  return (
    <ScrollView contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Setting</Text>
      {field('API key muapi.ai', mu, setMu, 'Untuk katalog besar (~220 model: Flux, Midjourney, Kling, Veo, dll). Ambil di muapi.ai.')}
      {field('API key kie.ai', kie, setKie, 'Untuk model kie.ai (Nano Banana, Seedance, Kling, GPT Image, dll). Ambil di kie.ai.')}
      <Text style={s.hint}>Cukup isi salah satu sesuai model yang dipakai. Key hanya disimpan di perangkat ini.</Text>
      <View>
        <Text style={s.label}>Sumber daftar model (online)</Text>
        <TextInput style={s.input} value={url} onChangeText={setUrlState} autoCapitalize="none" autoCorrect={false} />
        <Text style={[s.hint, { marginTop: 6 }]}>{status}{ts ? ` · diperbarui ${new Date(ts).toLocaleString()}` : ''} · Total {catalog.length} model. Diperbarui otomatis tiap app dibuka.</Text>
      </View>
      <Btn kind="ghost" title="Perbarui daftar model sekarang" onPress={async () => { await setUrl(url); const ok = await refresh(); Alert.alert(ok ? 'Berhasil' : 'Gagal', ok ? 'Daftar model diperbarui.' : 'Cek koneksi atau URL sumber.'); }} />
      <Btn title="Simpan" onPress={async () => { await setKey('muapi', mu); await setKey('kie', kie); Alert.alert('Tersimpan', 'API key disimpan.'); onSaved && onSaved(); }} />
    </ScrollView>
  );
}
