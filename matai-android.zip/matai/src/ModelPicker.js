import React, { useMemo, useState } from 'react';
import { Modal, View, Text, TextInput, FlatList, ScrollView, Pressable, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from './ui';

const hue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const initials = (s) => s.replace(/[^A-Za-z0-9 ]/g, '').split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';

const DOMAIN = {
  Google: 'gemini.google.com', OpenAI: 'openai.com', Flux: 'bfl.ai', Kling: 'klingai.com', ByteDance: 'bytedance.com',
  Alibaba: 'alibaba.com', Midjourney: 'midjourney.com', Ideogram: 'ideogram.ai', MiniMax: 'minimax.io', Runway: 'runwayml.com',
  Vidu: 'vidu.com', PixVerse: 'pixverse.ai', Lightricks: 'lightricks.com', Tencent: 'tencent.com', xAI: 'x.ai',
  Higgsfield: 'higgsfield.ai', Topaz: 'topazlabs.com', Reve: 'reve.com', Leonardo: 'leonardo.ai',
};
const logoUrl = (b) => (DOMAIN[b] ? `https://www.google.com/s2/favicons?domain=${DOMAIN[b]}&sz=128` : null);

function Dot({ label, size, on }) {
  const [failed, setFailed] = useState(false);
  const uri = logoUrl(label);
  const h = hue(label);
  const ring = { borderWidth: on ? 2 : 1, borderColor: on ? C.acc : C.line };
  if (uri && !failed) {
    return (
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: '#f2f2f5', alignItems: 'center', justifyContent: 'center', ...ring }}>
        <Image source={{ uri }} onError={() => setFailed(true)} style={{ width: size * 0.62, height: size * 0.62 }} resizeMode="contain" />
      </View>
    );
  }
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center',
      backgroundColor: `hsl(${h},35%,18%)`, ...ring }}>
      <Text style={{ color: `hsl(${h},80%,72%)`, fontWeight: '900', fontSize: size * 0.32 }}>{initials(label)}</Text>
    </View>
  );
}

// Rail vendor di kiri (digulir vertikal) + pencarian + daftar "All models" di kanan.
export default function ModelPicker({ visible, models, selected, onSelect, onClose }) {
  const insets = useSafeAreaInsets();
  const [q, setQ] = useState('');
  const [brand, setBrand] = useState('All');

  const brands = useMemo(() => {
    const c = {};
    models.forEach((m) => { c[m.brand] = (c[m.brand] || 0) + 1; });
    const names = Object.keys(c).filter((b) => b !== 'Lainnya').sort((a, b) => c[b] - c[a]);
    if (c['Lainnya']) names.push('Lainnya');
    return names.map((n) => ({ name: n, count: c[n] }));
  }, [models]);

  const data = useMemo(() => {
    const f = q.trim().toLowerCase();
    return models.filter((m) => (brand === 'All' || m.brand === brand) &&
      (!f || `${m.name} ${m.id} ${m.brand}`.toLowerCase().includes(f)));
  }, [models, q, brand]);

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: C.bg, paddingTop: insets.top }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', padding: 12, gap: 10 }}>
          <TextInput value={q} onChangeText={setQ} placeholder="Search models..." placeholderTextColor={C.mute}
            style={{ flex: 1, backgroundColor: C.card, color: C.text, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.line }} />
          <Pressable onPress={onClose}><Text style={{ color: C.acc, fontWeight: '800' }}>Tutup</Text></Pressable>
        </View>

        <View style={{ flex: 1, flexDirection: 'row' }}>
          <ScrollView style={{ width: 78, borderRightWidth: 1, borderRightColor: C.line }}
            contentContainerStyle={{ alignItems: 'center', gap: 10, paddingVertical: 8, paddingBottom: insets.bottom + 20 }}>
            {[{ name: 'All', count: models.length }, ...brands].map((b) => (
              <Pressable key={b.name} onPress={() => setBrand(b.name)} style={{ alignItems: 'center', width: 70 }}>
                <Dot label={b.name === 'All' ? 'All' : b.name} size={50} on={brand === b.name} />
                <Text numberOfLines={1} style={{ color: brand === b.name ? C.acc : C.mute, fontSize: 10, marginTop: 3 }}>{b.name}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <FlatList
            style={{ flex: 1 }}
            data={data}
            keyExtractor={(m) => m.key}
            contentContainerStyle={{ padding: 12, paddingBottom: insets.bottom + 20 }}
            initialNumToRender={20}
            ListHeaderComponent={<Text style={{ color: C.text, fontSize: 22, fontWeight: '800', marginBottom: 10 }}>
              {brand === 'All' ? 'All models' : brand} <Text style={{ color: C.mute, fontSize: 14 }}>· {data.length}</Text></Text>}
            ListEmptyComponent={<Text style={{ color: C.mute, paddingTop: 20 }}>Tidak ada model yang cocok.</Text>}
            renderItem={({ item }) => {
              const on = selected && selected.key === item.key;
              return (
                <Pressable onPress={() => { onSelect(item); onClose(); }}
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, marginBottom: 8, borderRadius: 14,
                    borderWidth: 1, borderColor: on ? C.acc : C.line, backgroundColor: on ? '#1d1d26' : C.card }}>
                  <Dot label={item.brand} size={40} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: C.text, fontWeight: '700', fontSize: 14 }}>{item.name}</Text>
                    <Text style={{ color: C.mute, fontSize: 11, marginTop: 2 }}>{item.provider === 'kie' ? 'kie.ai' : 'muapi.ai'}{item.family && item.provider === 'muapi' ? ` · ${item.family}` : ''}</Text>
                  </View>
                  {on ? <Text style={{ color: C.acc, fontSize: 18 }}>✓</Text> : null}
                </Pressable>
              );
            }}
          />
        </View>
      </View>
    </Modal>
  );
}
